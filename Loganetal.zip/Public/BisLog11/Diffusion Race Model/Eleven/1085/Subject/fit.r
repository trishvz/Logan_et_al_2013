# Read in code.  Constraint implements the model constraints, likelihoods is
# the same for most models except when summed parameter values are constrained,
# and then the parameter transformations within the likelihoods are different,
# and functions contain all the generic routines for getting data, computing
# Wald pdfs, probabilities, etc.
source(file='../constraint.r')
source(file='../../likelihoods.r')
source(file='../../../functions.r')

# Get the data:
subject <- 1
data <- get.data(subject)

# Some good starting values.  Avoid infinities.
pars <- c(
    3.7797773,   3.8139059, 4,  16.7078981,  16.4293821,  11.4565528,
   11.7141644,  11.2304099,   5.1400948,  5.1694398, 0,0,
    3.7797773,   3.8139059, 4,  16.7078981,  16.4293821,  11.4565528,
   11.7141644,  11.2304099,   5.1400948,  5.1694398, 0,0)

# Initial fit to whole data set; good for refining starting values
fit <- optim(pars, neg.log.likelihood, method = "Nelder-Mead",
           lower = -Inf, upper = Inf,control=list(trace=6,REPORT=1,maxit=100000),data=data)
pars <- constraint(fit$par)

# Split up data set by condition (2 stop-signal contexts)
   data.s <- data.by.context(data)
   pars.s <- pars.by.context(pars)
   data.0 <- data.s$data.0
   data.1 <- data.s$data.1
   
   pars.0 <- pars.s$pars.0
   pars.1 <- pars.s$pars.1

# To be safe:
save.image('temp.Rdata')


# Fit the first condition:
fit.0 <- optim(pars.0, neg.log.likelihood.0, method = "Nelder-Mead",
           lower = -Inf, upper = Inf,
           control=list(trace=1,maxit=100000),data=data.0)
pars.0 <- fit.0$par
save.image('temp.Rdata')

# Fit the second condition
fit.1 <- optim(pars.1, neg.log.likelihood.0, method = "Nelder-Mead",
           lower = -Inf, upper = Inf,
           control=list(trace=1,maxit=100000),data=data.1)
save.image('temp.Rdata')
pars.1 <- fit.1$par

# Put the parameters back into a common parameter vector:
pars <- all.pars(pars.0,pars.1)

# Fit the whole data set again:
fit <- optim(pars, neg.log.likelihood, method = "Nelder-Mead",
           lower = -Inf, upper = Inf,control=list(trace=1,maxit=100000),data=data)
save.image('temp.Rdata')
pars <- constraint(fit$par)

save(data,pars,fit.0,fit.1,fit,file='subj.Rdata')

# Go on to looping stage
