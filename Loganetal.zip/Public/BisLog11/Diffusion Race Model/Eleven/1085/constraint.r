constraint <- function(pars) {

  pars[c(2,13,14)] <- pars[1]
  pars[c(5,16,17)] <- pars[4]
  pars[c(7,18,19)] <- pars[6]
  pars[21] <- pars[9]
  pars[23] <- pars[11]
  

  pars
}

