constraint <- function(pars) {

  pars[c(2,13,14)] <- pars[1]
   pars[5] <- pars[4]
   pars[17] <- pars[16]

   pars[7] <- pars[6]
   pars[19] <- pars[18]

    pars[21] <- pars[9]


  pars
}

