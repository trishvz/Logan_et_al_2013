constraint <- function(pars) {
   pars[2] <- pars[1]
   pars[14] <- pars[13]
  pars[c(5,16,17)] <- pars[4]
   pars[c(7,18,19)] <- pars[6]
   pars[23] <- pars[11]
  pars
}

