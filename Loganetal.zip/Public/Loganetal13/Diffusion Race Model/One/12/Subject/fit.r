# Read in code.  Constraint implements the model constraints, likelihoods is
# the same for most models except when summed parameter values are constrained,
# and then the parameter transformations within the likelihoods are different,
# and functions contain all the generic routines for getting data, computing
# Wald pdfs, probabilities, etc.
source(file='../constraint.r')
source(file='../../likelihoods.r')
source(file='../../../functions.r')

# Get the data:
subject <- 1
data <- get.data(subject)

# Some good starting values (derived from fits to the diffusion race with no
# starting point variability).  Avoid infinities.
pars <- c(
   5.657174,   7.647878,  12.059135,  11.132340,  12.481634,   0.000000,
   0.000000,   5.657174,   7.647878,  13.467557,  11.346167,  12.481634,
   0.000000,   0.000000,   5.657174,   7.647878,  44.144208,  11.501793,
  12.481634,   0.000000,   0.000000,   0.050844, -11.114822)
          
          
# Initial fit to whole data set; good for refining starting values
fit <- optim(pars, neg.log.likelihood, method = "Nelder-Mead",
           lower = -Inf, upper = Inf,
           control=list(trace=6,REPORT=1,maxit=100000),data=data)
pars <- constraint(fit$par)

# Split up data set by condition (2, 4, 6 response alternatives)
   data.s <- data.by.choices(data)
   pars.s <- pars.by.choices(pars)
   data.2 <- data.s$data.2
   data.4 <- data.s$data.4
   data.6 <- data.s$data.6
   
   pars.2 <- pars.s$pars.2
   pars.4 <- pars.s$pars.4
   pars.6 <- pars.s$pars.6

# To be safe:
save.image('temp.Rdata')

# Fit the 2-choice condition
fit.2 <- optim(pars.2, neg.log.likelihood.2, method = "Nelder-Mead",
           lower = -Inf, upper = Inf,control=list(trace=1,maxit=100000),data=data.2)
pars.2 <- fit.2$par
save.image('temp.Rdata')

# Fit the 4-choice condition
fit.4 <- optim(pars.4, neg.log.likelihood.4, method = "Nelder-Mead",
           lower = -Inf, upper = Inf,control=list(trace=1,maxit=100000),data=data.4)
save.image('temp.Rdata')
pars.4 <- fit.4$par

# Fit the 6-choice condition
fit.6 <- optim(pars.6, neg.log.likelihood.6, method = "Nelder-Mead",
           lower = -Inf, upper = Inf,control=list(trace=1,maxit=100000),data=data.6)
save.image('temp.Rdata')
pars.6 <- fit.6$par

# Put the parameters back into a common parameter vector:
pars <- all.pars(pars.2,pars.4,pars.6)

# Compute the minimum RT
t.m <- min(data$rt[data$rt>0])

# Adjust the parameters for the nondecision time by averaging over the
# conditions:
t.0 <- mean(t.m/(1+exp(c(pars.2[6],pars.4[6],pars.6[6]))))
t.1 <- mean(t.m/(1+exp(c(pars.2[7],pars.4[7],pars.6[7]))))
pars[c(2,7,12)] <- mean(pars[c(2,7,12)])
pars[c(5,10,15)] <- mean(pars[c(5,10,15)])
pars[16:17] <- log(t.m/c(t.0,t.1)-1)

# Fit the whole data set again
fit <- optim(pars, neg.log.likelihood, method = "Nelder-Mead",
           lower = -Inf, upper = Inf,control=list(trace=1,maxit=100000),data=data)
save.image('temp.Rdata')
pars <- constraint(fit$par)

save(data,pars,fit.2,fit.4,fit.6,fit,file='subj.Rdata')

# Go on to looping stage

