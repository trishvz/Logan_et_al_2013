# Begin with obtained starting values:
load('subj.Rdata')
source(file='../constraint.r')
source(file='../../likelihoods.r')
source(file='../../../functions.r')

# Optimize 25 times or until likelihood no longer changes.
for (i in 1:25) {
fit <- optim(pars, neg.log.likelihood, method = "Nelder-Mead",
           lower = -Inf, upper = Inf,control=list(trace=1,maxit=100000),data=data)
save.image('temp.Rdata')
pars <- constraint(fit$par)
}

save(data,pars,fit.2,fit.4,fit.6,fit,file='subj.Rdata')

