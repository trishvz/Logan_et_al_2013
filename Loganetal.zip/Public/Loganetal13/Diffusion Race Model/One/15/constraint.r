constraint <- function(pars) {

  pars[c(8,15)] <- pars[1]
  
  pars[c(13,20)] <- pars[6]
  pars[c(14,21)] <- pars[7]

  pars
}
