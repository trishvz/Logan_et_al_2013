constraint <- function(pars) {

  pars[c(9,16)] <- pars[2]

  pars[c(12,19)] <- pars[5]

  pars[c(13,20)] <- pars[6]
  pars[c(14,21)] <- pars[7]

  pars
}
