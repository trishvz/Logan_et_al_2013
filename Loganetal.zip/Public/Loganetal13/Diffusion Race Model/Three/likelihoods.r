# R Code to fit the models reported in Logan, Van Zandt, Verbruggen, and
# Wagenmakers (in press).  On the ability to inhibit thought and action:
# General and special theories of an act of control.  Psychological Review.
#
# Copyright (C) 2013  Trisha Van Zandt
#
# This program is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free
# Software Foundation, either version 3 of the License, or (at your option)
# any later version.
#
#This program is distributed in the hope that it will be useful, but WITHOUT
#ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
#FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
#more details.
#
#To read the GNU General Public License, see <http://www.gnu.org/licenses/>.
neg.log.likelihood.2 <- function(pars,data) {
  t <- data$rt 
  t.s <- data$ssd 
  cat <- data$category 
  resp <- data$resp 
  small <- 1e-6
  min.rt <- data$min.rt

  k <- .1+3999.9/(1+exp(pars[1]))  
  k.s <- rep(.1+3999.9/(1+exp(pars[2])),times=length(cat))
  
  k.a <- rep(NA,times=length(resp))
  k.b <- rep(NA,times=length(resp))
  l.a <- rep(NA,times=length(resp))
  l.b <- rep(NA,times=length(resp))

  mu <- 10000/(1+exp(pars[3])) 

  l.1 <- mu + (cat==1)*10000/(1+exp(pars[4]))
  l.2 <- mu + (cat==2)*10000/(1+exp(pars[4]))
  l.s <- rep(20000/(1+exp(pars[5])),times=length(cat))

  a <- 1*k/(1+ exp(pars[6]))
  a.s <- 1*k.s/(1+exp(pars[7]))

  a.a <- rep(NA,times=length(resp))
  a.b <- rep(NA,times=length(resp))


  for (i in 1:length(resp)) {
    n <- resp[i]
    if(n==1 | n<0) {
      l.a[i] <- l.1[i]
      l.b[i] <- l.2[i]
      k.a[i] <- k
      k.b[i] <- k
      a.a[i] <- a
      a.b[i] <- a
    }
    if(n==2) {
      l.a[i] <- l.2[i]
      l.b[i] <- l.1[i]
      k.a[i] <- k
      k.b[i] <- k
      a.a[i] <- a
      a.b[i] <- a
    }
}

  t.0 <- min.rt/(1+exp(pars[8])) 
  t.1 <- min.rt/(1+exp(pars[9])) 
  y <- f.2(t-t.0,t.s+t.1-t.0,k.a,k.b,k.s,l.a,l.b,l.s,a.a,a.b,a.s) 
  ly <- log(y) 
  ly[ly==-Inf] <- -750 
  -sum(ly) 
}

neg.log.likelihood.4 <- function(pars,data) {
  small <- 1e-6
  t <- data$rt 
  t.s <- data$ssd 
  cat <- data$category 
  resp <- data$resp 
  min.rt <- data$min.rt
  
  k <- .1+3999.9/(1+exp(pars[1]))  
  k.s <- rep(.1+3999.9/(1+exp(pars[2])),times=length(cat))

  k.a <- rep(NA,times=length(resp))
  k.b <- rep(NA,times=length(resp))
  k.c <- rep(NA,times=length(resp))
  k.d <- rep(NA,times=length(resp))
  l.a <- rep(NA,times=length(resp))
  l.b <- rep(NA,times=length(resp))
  l.c <- rep(NA,times=length(resp))
  l.d <- rep(NA,times=length(resp))

  mu <- 10000/(1 + exp(pars[3]))

  l.1 <- mu + (cat==1)*10000/(1+exp(pars[4]))
  l.2 <- mu + (cat==2)*10000/(1+exp(pars[4]))
  l.3 <- mu + (cat==3)*10000/(1+exp(pars[4]))
  l.4 <- mu + (cat==4)*10000/(1+exp(pars[4]))
  l.s <- rep(20000/(1+exp(pars[5])),times=length(cat))

  a <- 1*k/(1+ exp(pars[6]))
  a.s <- 1*k.s/(1+exp(pars[7]))
  
  a.a <- rep(NA,times=length(resp))
  a.b <- rep(NA,times=length(resp))
  a.c <- rep(NA,times=length(resp))
  a.d <- rep(NA,times=length(resp))
  
  for (i in 1:length(resp)) {
    n <- resp[i]
    if(n==1 | n<0) {
      l.a[i] <- l.1[i]
      l.b[i] <- l.2[i]
      l.c[i] <- l.3[i]
      l.d[i] <- l.4[i]
      k.a[i] <- k
      k.b[i] <- k
      k.c[i] <- k
      k.d[i] <- k
      a.a[i] <- a
      a.b[i] <- a 
      a.c[i] <- a
      a.d[i] <- a
    }
    if(n==2) {
      l.a[i] <- l.2[i]
      l.b[i] <- l.1[i]
      l.c[i] <- l.3[i]
      l.d[i] <- l.4[i]
      k.a[i] <- k
      k.b[i] <- k
      k.c[i] <- k
      k.d[i] <- k
      a.a[i] <- a
      a.b[i] <- a 
      a.c[i] <- a
      a.d[i] <- a
    }
    if(n==3) {
      l.a[i] <- l.3[i]
      l.b[i] <- l.1[i]
      l.c[i] <- l.2[i]
      l.d[i] <- l.4[i]
      k.a[i] <- k
      k.b[i] <- k
      k.c[i] <- k
      k.d[i] <- k
      a.a[i] <- a
      a.b[i] <- a 
      a.c[i] <- a
      a.d[i] <- a
    }
    if(n==4) {
      l.a[i] <- l.4[i]
      l.b[i] <- l.1[i]
      l.c[i] <- l.2[i]
      l.d[i] <- l.3[i]
      k.a[i] <- k
      k.b[i] <- k
      k.c[i] <- k
      k.d[i] <- k
      a.a[i] <- a
      a.b[i] <- a 
      a.c[i] <- a
      a.d[i] <- a
    }
  }


  t.0 <- min.rt/(1+exp(pars[8])) 
  t.1 <- min.rt/(1+exp(pars[9])) 

  y <- f.4(t-t.0,t.s+t.1-t.0,k.a,k.b,k.c,k.d,k.s,
           l.a,l.b,l.c,l.d,l.s,a.a,a.b,a.c,a.d,a.s) 
  ly <- log(y) 
  ly[ly==-Inf] <- -750 
  -sum(ly) 
}

neg.log.likelihood.6 <- function(pars,data) {
  small <- 1e-6
  t <- data$rt 
  t.s <- data$ssd 
  cat <- data$category 
  resp <- data$resp 
  min.rt <- data$min.rt
  
  k <- .1+3999.9/(1+exp(pars[1]))  
  k.s <- rep(.1+3999.9/(1+exp(pars[2])),times=length(cat))

  k.a <- rep(NA,times=length(resp))
  k.b <- rep(NA,times=length(resp))
  k.c <- rep(NA,times=length(resp))
  k.d <- rep(NA,times=length(resp))
  k.e <- rep(NA,times=length(resp))
  k.f <- rep(NA,times=length(resp))
  l.a <- rep(NA,times=length(resp))
  l.b <- rep(NA,times=length(resp))
  l.c <- rep(NA,times=length(resp))
  l.d <- rep(NA,times=length(resp))
  l.e <- rep(NA,times=length(resp))
  l.f <- rep(NA,times=length(resp))
  a.a <- rep(NA,times=length(resp))
  a.b <- rep(NA,times=length(resp))
  a.c <- rep(NA,times=length(resp))
  a.d <- rep(NA,times=length(resp))
  a.e <- rep(NA,times=length(resp))
  a.f <- rep(NA,times=length(resp))

  mu <- 10000/(1 + exp(pars[3]))

  l.1 <- mu + (cat==1)*10000/(1+exp(pars[4]))
  l.2 <- mu + (cat==2)*10000/(1+exp(pars[4]))
  l.3 <- mu + (cat==3)*10000/(1+exp(pars[4]))
  l.4 <- mu + (cat==4)*10000/(1+exp(pars[4]))
  l.5 <- mu + (cat==5)*10000/(1+exp(pars[4]))
  l.6 <- mu + (cat==6)*10000/(1+exp(pars[4]))
  l.s <- rep(20000/(1+exp(pars[5])),times=length(cat))
  
  a <- 1*k/(1+ exp(pars[6]))
  a.s <- 1*k.s/(1+exp(pars[7]))

  for (i in 1:length(resp)) {
    n <- resp[i]
    if(n==1 | n<0) {
      l.a[i] <- l.1[i]
      l.b[i] <- l.2[i]
      l.c[i] <- l.3[i]
      l.d[i] <- l.4[i]
      l.e[i] <- l.5[i]
      l.f[i] <- l.6[i]
      k.a[i] <- k
      k.b[i] <- k
      k.c[i] <- k
      k.d[i] <- k
      k.e[i] <- k
      k.f[i] <- k
      a.a[i] <- a
      a.b[i] <- a
      a.c[i] <- a
      a.d[i] <- a
      a.e[i] <- a
      a.f[i] <- a
    }
    if(n==2) {
      l.a[i] <- l.2[i]
      l.b[i] <- l.1[i]
      l.c[i] <- l.3[i]
      l.d[i] <- l.4[i]
      l.e[i] <- l.5[i]
      l.f[i] <- l.6[i]
      k.a[i] <- k
      k.b[i] <- k
      k.c[i] <- k
      k.d[i] <- k
      k.e[i] <- k
      k.f[i] <- k
      a.a[i] <- a
      a.b[i] <- a
      a.c[i] <- a
      a.d[i] <- a
      a.e[i] <- a
      a.f[i] <- a
    }
    if(n==3) {
      l.a[i] <- l.3[i]
      l.b[i] <- l.1[i]
      l.c[i] <- l.2[i]
      l.d[i] <- l.4[i]
      l.e[i] <- l.5[i]
      l.f[i] <- l.6[i]
      k.a[i] <- k
      k.b[i] <- k
      k.c[i] <- k
      k.d[i] <- k
      k.e[i] <- k
      k.f[i] <- k
      a.a[i] <- a
      a.b[i] <- a
      a.c[i] <- a
      a.d[i] <- a
      a.e[i] <- a
      a.f[i] <- a
    }
    if(n==4) {
      l.a[i] <- l.4[i]
      l.b[i] <- l.1[i]
      l.c[i] <- l.2[i]
      l.d[i] <- l.3[i]
      l.e[i] <- l.5[i]
      l.f[i] <- l.6[i]
      k.a[i] <- k
      k.b[i] <- k
      k.c[i] <- k
      k.d[i] <- k
      k.e[i] <- k
      k.f[i] <- k
      a.a[i] <- a
      a.b[i] <- a
      a.c[i] <- a
      a.d[i] <- a
      a.e[i] <- a
      a.f[i] <- a
    }
    if(n==5) {
      l.a[i] <- l.5[i]
      l.b[i] <- l.1[i]
      l.c[i] <- l.2[i]
      l.d[i] <- l.3[i]
      l.e[i] <- l.4[i]
      l.f[i] <- l.6[i]
      k.a[i] <- k
      k.b[i] <- k
      k.c[i] <- k
      k.d[i] <- k
      k.e[i] <- k
      k.f[i] <- k
      a.a[i] <- a
      a.b[i] <- a
      a.c[i] <- a
      a.d[i] <- a
      a.e[i] <- a
      a.f[i] <- a
    }
    if(n==6) {
      l.a[i] <- l.6[i]
      l.b[i] <- l.1[i]
      l.c[i] <- l.2[i]
      l.d[i] <- l.3[i]
      l.e[i] <- l.4[i]
      l.f[i] <- l.5[i]
      k.a[i] <- k
      k.b[i] <- k
      k.c[i] <- k
      k.d[i] <- k
      k.e[i] <- k
      k.f[i] <- k
      a.a[i] <- a
      a.b[i] <- a
      a.c[i] <- a
      a.d[i] <- a
      a.e[i] <- a
      a.f[i] <- a
    }
  }


  t.0 <- min.rt/(1+exp(pars[8])) 
  t.1 <- min.rt/(1+exp(pars[9])) 

  y <- f.6(t-t.0,t.s+t.1-t.0,k.a,k.b,k.c,k.d,k.e,k.f,k.s,
           l.a,l.b,l.c,l.d,l.e,l.f,l.s,
           a.a,a.b,a.c,a.d,a.e,a.f,a.s) 
  ly <- log(y) 
  ly[ly==-Inf] <- -750 
  -sum(ly) 
}

transform <- function(pars,t.m=0){

    pars <- constraint(pars)
    k.2 <- .1+3999.9/(1+exp(pars[1:2]))  

    mu.2 <- 10000/(1+exp(pars[3]))
    l2 <- c(mu.2,0) +
          c(10000/(1+exp(pars[4])),20000/(1+exp(pars[5])))

    a.2 <- k.2/(1+exp(pars[6:7]))
                        

    k.4 <- .1+3999.9/(1+exp(pars[8:9]))  
    mu.4 <- 10000/(1+exp(pars[10]) )
    l4 <- c(mu.4,0) + 
          c(10000/(1+exp(pars[11])),20000/(1+exp(pars[12])))
                      
    a.4 <- k.4/(1+exp(pars[13:14]))
    
    k.6 <- .1+3999.9/(1+exp(pars[15:16]))  
    mu.6 <- 10000/(1+exp(pars[17]))
    l6 <- c(mu.6,0) + 
          c(10000/(1+exp(pars[18])),20000/(1+exp(pars[19])))

    a.6 <- k.6/(1+exp(pars[20:21]))
    
    
    t.0 <- t.m/(1+exp(pars[22:23])) 

    list(k2=c(k.2[1],k.2),
         k4=c(rep(k.4[1],times=3),k.4),
         k6=c(rep(k.6[1],times=5),k.6),
         mu2=c(mu.2,mu.2),
         mu4=rep(mu.4,times=4),
         mu6=rep(mu.6,times=6),
         l2=c(l2[1],l2),
         l4=c(rep(l4[1],times=3),l4),
         l6=c(rep(l6[1],times=5),l6),
         a.2=c(a.2[1],a.2),
         a.4=c(rep(a.4[1],times=3),a.4),
         a.6=c(rep(a.6[1],times=5),a.6),t.0=t.0)

}

