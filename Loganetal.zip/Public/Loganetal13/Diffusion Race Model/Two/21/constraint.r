constraint <- function(pars) {

  pars[c(10,17)] <- pars[3]

  pars[c(11,18)] <- pars[4]

  pars[c(13,20)] <- pars[6]
  pars[c(14,21)] <- pars[7]

  pars
}
