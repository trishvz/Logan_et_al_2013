# R Code to fit the models reported in Logan, Van Zandt, Verbruggen, and
# Wagenmakers (in press).  On the ability to inhibit thought and action:
# General and special theories of an act of control.  Psychological Review.
#
# Copyright (C) 2013  Trisha Van Zandt
#
# This program is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free
# Software Foundation, either version 3 of the License, or (at your option)
# any later version.
#
#This program is distributed in the hope that it will be useful, but WITHOUT
#ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
#FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
#more details.
#
#To read the GNU General Public License, see <http://www.gnu.org/licenses/>.
rlevy <- function(n=1, m=0, c=1) {
  if (any(c<0)) stop("c must be positive")
  c/qnorm(1-runif(n)/2)^2+m
}



rwald <- function(n,k,l) {
  if(length(k)==1) k <- rep(k,times=n)
  if(length(l)==1) l <- rep(l,times=n)

  tiny <- 1e-6
  flag <- l>tiny
  x <- rep(NA,times=n)
  
  x[!flag] <- rlevy(sum(!flag),0,k[!flag]^2)
  mu <- k/l
  lambda <- k^2

  y <- rnorm(sum(flag))^2
  mu.0 <- mu[flag]
  lambda.0 <- lambda[flag]

  x.0 <- mu.0 + mu.0^2*y/(2*lambda.0) -
      sqrt(4*mu.0*lambda.0*y +
      mu.0^2*y^2)*mu.0/(2*lambda.0)

  z <- runif(length(x.0))
  test <- mu.0/(mu.0+x.0)
  x.0[z>test] <- mu.0[z>test]^2/x.0[z>test]
  x[flag] <- x.0
  x[x<0] <- max(x)
  x
}

digt.0 <- function(t,k=1,l=1) {
  options(warn=-1)
  if(length(k)==1) k <- rep(k,times=length(t))
  if(length(l)==1) l <- rep(l,times=length(t))

  mu <- k/l
  lambda <- k^2

  e <- -(lambda/(2*t)) * (t^2/mu^2 - 2*t/mu  + 1)

  e[mu==Inf] <- -.5*lambda/t
  con <- .5*log(lambda) - .5*log(2*t^3*pi)

  x <- exp(e+con)
  x[t<=0] <- 0
  x
}


pigt.0 <- function(t,k=1,l=1) {
  options(warn=-1)
  if(length(k)==1) k <- rep(k,times=length(t))
  if(length(l)==1) l <- rep(l,times=length(t))

  mu <- k/l
  lambda <- k^2

  e <- exp(log(2*lambda) - log(mu))
  add <- sqrt(lambda/t) * (1 + t/mu)
  sub <- sqrt(lambda/t) * (1 - t/mu)

  p.1 <- 1 - pnorm(add)
  p.2 <- 1 - pnorm(sub)

  x <- exp(e + log(p.1)) + p.2

  x[t<0] <- 0
  x

}


digt <- function(t,k=1,l=1,a=1) {
  options(warn=-1)
  if(length(k)==1) k <- rep(k,times=length(t))
  if(length(l)==1) l <- rep(l,times=length(t))
  if(length(a)==1) a <- rep(a,times=length(t))
  tiny <- 10^(-10)

  a[a<=tiny] <- 0
  l[l<=tiny] <- 0
  
  sqr.t <- sqrt(t)
  log.t <- log(t)


  term.1a <- -(a-k+t*l)^2/(2*t)
  term.1b <- -(a+k-t*l)^2/(2*t)
  term.1 <- (exp(term.1a) - exp(term.1b))/sqrt(2*pi*t)

  term.2a <- log(.5)+log(l)
  term.2b <- 2*pnorm((-k+a)/sqr.t+sqr.t*l)-1
  term.2c <- 2*pnorm((k+a)/sqr.t-sqr.t*l)-1
  term.2d <- term.2b+term.2c
  term.2 <- exp(term.2a)*term.2d

  term.3 <- term.1+term.2
  term.4 <- log(term.3)-log(2)-log(a)
  x <- exp(term.4)


  term.1 <- -.5*(log(2)+log(pi)+log.t)
  term.2 <- (k-a)^2/(2*t)
  term.3 <- (k+a)^2/(2*t)
  term.4 <- (exp(-term.2[l==0])-exp(-term.3[l==0]))
  term.5 <- term.1[l==0]+log(term.4) - log(2) - log(a[l==0])
  x[l==0] <- exp(term.5)

  x[a<=tiny] <- digt.0(t[a<=tiny],k[a<=tiny],l[a<=tiny])

  x[t<=0] <- 0
  x[x<0 | is.nan(x) ] <- 0

  x
}


pigt <- function(t,k=1,l=1,a=1) {
  options(warn=-1)
  if(length(k)==1) k <- rep(k,times=length(t))
  if(length(l)==1) l <- rep(l,times=length(t))
  if(length(a)==1) a <- rep(a,times=length(t))
  tiny <- 10^(-10)

  l[l<=tiny] <- 0
  a[a<=tiny] <- 0


  
  sqr.t <- sqrt(t)
  log.t <- log(t)

  term.1a <- .5*log.t-.5*log(2*pi)
  term.1b <- exp(-((k-a-t*l)^2/t )/2)
  term.1c <- exp(-((k+a-t*l)^2/t )/2)
  term.1 <- exp(term.1a)*(term.1b-term.1c)

  term.2a <- exp(2*l*(k-a)+ log(pnorm(-(k-a+t*l)/sqr.t)))
  term.2b <- exp(2*l*(k+a)+ log(pnorm(-(k+a+t*l)/sqr.t)))
  term.2 <- a + (term.2b-term.2a)/(2*l)

  term.4a <- 2*pnorm((k+a)/sqr.t-sqr.t*l)-1
  term.4b <- 2*pnorm((k-a)/sqr.t-sqr.t*l)-1
  term.4c <- .5*(t*l - a - k + .5/l)
  term.4d <- .5*(k - a - t*l - .5/l)
  term.4 <- term.4c*term.4a + term.4d*term.4b

  term <- (term.4 + term.2 + term.1)/(2*a)
  x <- (term)

  term.5a <- 2*pnorm((k+a)/sqr.t)-1
  term.5b <- 2*pnorm(-(k-a)/sqr.t)-1
  term.5 <- (-(k+a)*term.5a - (k-a)*term.5b)/(2*a)

  term.6a <- -.5*(k+a)^2/t - .5*log(2) -.5*log(pi) + .5*log.t - log(a)
  term.6b <- -.5*(k-a)^2/t - .5*log(2) -.5*log(pi) + .5*log.t - log(a)
  term.6 <- 1 + exp(term.6b) - exp(term.6a)

  term.7 <- term.5 + term.6
  
  x[l<=0] <- term.7[l<=0]

  x[a<=0] <- pigt.0(t[a<=0],k[a<=0],l[a<=0])

  x[t<0] <- 0
  x[x<0 | is.nan(x) ] <- 0
  x

}



f.2 <- function(t,t.s,k.a=1,k.b=1,k.s=1,
                 l.a=1,l.b=1,l.s=1,
                 a.a=1,a.b=1,a.s=1) {
  pdf <- rep(0,times=length(t))

  if (length(k.a)==1) k.a <- rep(k.a,times=length(t))
  if (length(k.b)==1) k.b <- rep(k.b,times=length(t))
  if (length(k.s)==1) k.s <- rep(k.s,times=length(t))
  if (length(l.a)==1) l.a <- rep(l.a,times=length(t))
  if (length(l.b)==1) l.b <- rep(l.b,times=length(t))
  if (length(l.s)==1) l.s <- rep(l.s,times=length(t))
  if (length(a.a)==1) a.a <- rep(a.a,times=length(t))
  if (length(a.b)==1) a.b <- rep(a.b,times=length(t))
  if (length(a.s)==1) a.s <- rep(a.s,times=length(t))
  if (length(t.s)==1) t.s <- rep(t.s,times=length(t))


  p <- p.2(t.s,k.a,k.b,k.s,l.a,l.b,l.s,a.a,a.b,a.s)
  n <- length(p)
  pdf[t>0 & t<=t.s] <- digt(t[t>0 & t<=t.s],
        k=k.a[t>0 & t<=t.s],l=l.a[t>0 & t<=t.s],a=a.a[t>0 & t<=t.s])*
        (1-pigt(t[t>0 & t<=t.s],
        k=k.b[t>0 & t<=t.s],l=l.b[t>0 & t<=t.s],a=a.b[t>0 & t<=t.s]))
  pdf[t>t.s] <- digt(t[t>t.s],
        k=k.a[t>t.s],l=l.a[t>t.s],a=a.a[t>t.s])*
        (1-pigt(t[t>t.s],k=k.b[t>t.s],l=l.b[t>t.s],a=a.b[t>t.s]))*
        (1-pigt(t[t>t.s]-t.s[t>t.s],k=k.s[t>t.s],
                l=l.s[t>t.s],a=a.s[t>t.s]))

  pdf[t<0] <- p[t<0]
    pdf[pdf<0] <- 0
  pdf
}

f.4 <- function(t,t.s,k.a=1,k.b=1,k.c=1,k.d=1,k.s=1,
                l.a=1,l.b=1,l.c=1,l.d=1,l.s=1,
                a.a=0,a.b=0,a.c=0,a.d=0,a.s=0) {
  pdf <- rep(0,times=length(t))

  if (length(k.a)==1) k.a <- rep(k.a,times=length(t))
  if (length(k.b)==1) k.b <- rep(k.b,times=length(t))
  if (length(k.c)==1) k.c <- rep(k.c,times=length(t))
  if (length(k.d)==1) k.d <- rep(k.d,times=length(t))
  if (length(k.s)==1) k.s <- rep(k.s,times=length(t))
  if (length(l.a)==1) l.a <- rep(l.a,times=length(t))
  if (length(l.b)==1) l.b <- rep(l.b,times=length(t))
  if (length(l.c)==1) l.c <- rep(l.c,times=length(t))
  if (length(l.d)==1) l.d <- rep(l.d,times=length(t))
  if (length(l.s)==1) l.s <- rep(l.s,times=length(t))
  if (length(a.a)==1) a.a <- rep(a.a,times=length(t))
  if (length(a.b)==1) a.b <- rep(a.b,times=length(t))
  if (length(a.c)==1) a.c <- rep(a.c,times=length(t))
  if (length(a.d)==1) a.d <- rep(a.d,times=length(t))
  if (length(a.s)==1) a.s <- rep(a.s,times=length(t))
  if (length(t.s)==1) t.s <- rep(t.s,times=length(t))
  
  p <- p.4(t.s,k.a,k.b,k.c,k.d,k.s,
           l.a,l.b,l.c,l.d,l.s,
           a.a,a.b,a.c,a.d,a.s)

  pdf[t>0 & t<=t.s] <-
    digt(t[t>0 & t<=t.s],
         k=k.a[t>0 & t<=t.s],l=l.a[t>0 & t<=t.s],a=a.a[t>0 & t<=t.s])*
    (1-pigt(t[t>0 & t<=t.s],
         k=k.b[t>0 & t<=t.s],l=l.b[t>0 & t<=t.s],a=a.b[t>0 & t<=t.s]))*
    (1-pigt(t[t>0 & t<=t.s],
         k=k.c[t>0 & t<=t.s],l=l.c[t>0 & t<=t.s],a=a.c[t>0 & t<=t.s]))*
    (1-pigt(t[t>0 & t<=t.s],
         k=k.d[t>0 & t<=t.s],l=l.d[t>0 & t<=t.s],a=a.d[t>0 & t<=t.s]))
  
  pdf[t>t.s] <-
    digt(t[t>t.s],k=k.a[t>t.s],l=l.a[t>t.s],a=a.a[t>t.s])*
    (1-pigt(t[t>t.s],k=k.b[t>t.s],l=l.b[t>t.s],a=a.b[t>t.s]))*
    (1-pigt(t[t>t.s],k=k.c[t>t.s],l=l.c[t>t.s],a=a.c[t>t.s]))*
    (1-pigt(t[t>t.s],k=k.d[t>t.s],l=l.d[t>t.s],a=a.d[t>t.s]))*
    (1-pigt(t[t>t.s]-t.s[t>t.s],k=k.s[t>t.s],l=l.s[t>t.s],a=a.s[t>t.s]))

  pdf[t<0] <- p[t<0]
  
    pdf[pdf<0] <- 0

  pdf
}

f.6 <- function(t,t.s,k.a=1,k.b=1,k.c=1,k.d=1,k.e=1,k.f=1,k.s=1,
                l.a=1,l.b=1,l.c=1,l.d=1,l.e=1,l.f=1,l.s=1,
                a.a=0,a.b=0,a.c=0,a.d=0,a.e=0,a.f=0,a.s=0) {
                
  pdf <- rep(0,times=length(t))

  if (length(k.a)==1) k.a <- rep(k.a,times=length(t))
  if (length(k.b)==1) k.b <- rep(k.b,times=length(t))
  if (length(k.c)==1) k.c <- rep(k.c,times=length(t))
  if (length(k.d)==1) k.d <- rep(k.d,times=length(t))
  if (length(k.e)==1) k.e <- rep(k.e,times=length(t))
  if (length(k.f)==1) k.f <- rep(k.f,times=length(t))
  if (length(k.s)==1) k.s <- rep(k.s,times=length(t))
  if (length(l.a)==1) l.a <- rep(l.a,times=length(t))
  if (length(l.b)==1) l.b <- rep(l.b,times=length(t))
  if (length(l.c)==1) l.c <- rep(l.c,times=length(t))
  if (length(l.d)==1) l.d <- rep(l.d,times=length(t))
  if (length(l.e)==1) l.e <- rep(l.e,times=length(t))
  if (length(l.f)==1) l.f <- rep(l.f,times=length(t))
  if (length(l.s)==1) l.s <- rep(l.s,times=length(t))
  if (length(a.a)==1) a.a <- rep(a.a,times=length(t))
  if (length(a.b)==1) a.b <- rep(a.b,times=length(t))
  if (length(a.c)==1) a.c <- rep(a.c,times=length(t))
  if (length(a.d)==1) a.d <- rep(a.d,times=length(t))
  if (length(a.e)==1) a.e <- rep(a.e,times=length(t))
  if (length(a.f)==1) a.f <- rep(a.f,times=length(t))
  if (length(a.s)==1) a.s <- rep(a.s,times=length(t))
  if (length(t.s)==1) t.s <- rep(t.s,times=length(t))

  p <- p.6(t.s,k.a,k.b,k.c,k.d,k.e,k.f,k.s,
           l.a,l.b,l.c,l.d,l.e,l.f,l.s,
           a.a,a.b,a.c,a.d,a.e,a.f,a.s)

  pdf[t>0 & t<=t.s] <-
    digt(t[t>0 & t<=t.s],
         k=k.a[t>0 & t<=t.s],l=l.a[t>0 & t<=t.s],a=a.a[t>0 & t<=t.s])*
     (1-pigt(t[t>0 & t<=t.s],
         k=k.b[t>0 & t<=t.s],l=l.b[t>0 & t<=t.s],a=a.b[t>0 & t<=t.s]))*
     (1-pigt(t[t>0 & t<=t.s],
         k=k.c[t>0 & t<=t.s],l=l.c[t>0 & t<=t.s],a=a.c[t>0 & t<=t.s]))*
     (1-pigt(t[t>0 & t<=t.s],
         k=k.d[t>0 & t<=t.s],l=l.d[t>0 & t<=t.s],a=a.d[t>0 & t<=t.s]))*
     (1-pigt(t[t>0 & t<=t.s],
         k=k.e[t>0 & t<=t.s],l=l.e[t>0 & t<=t.s],a=a.e[t>0 & t<=t.s]))*
     (1-pigt(t[t>0 & t<=t.s],
         k=k.f[t>0 & t<=t.s],l=l.f[t>0 & t<=t.s],a=a.f[t>0 & t<=t.s]))
  
  pdf[t>t.s] <- digt(t[t>t.s],k=k.a[t>t.s],l=l.a[t>t.s],a=a.a[t>t.s])*
       (1-pigt(t[t>t.s],k=k.b[t>t.s],l=l.b[t>t.s],a=a.b[t>t.s]))*
       (1-pigt(t[t>t.s],k=k.c[t>t.s],l=l.c[t>t.s],a=a.c[t>t.s]))*
       (1-pigt(t[t>t.s],k=k.d[t>t.s],l=l.d[t>t.s],a=a.d[t>t.s]))*
       (1-pigt(t[t>t.s],k=k.e[t>t.s],l=l.e[t>t.s],a=a.e[t>t.s]))*
       (1-pigt(t[t>t.s],k=k.f[t>t.s],l=l.f[t>t.s],a=a.f[t>t.s]))*
       (1-pigt(t[t>t.s]-t.s[t>t.s],
               k=k.s[t>t.s],l=l.s[t>t.s],a=a.s[t>t.s]))

  pdf[t<0] <- p[t<0]
  
    pdf[pdf<0] <- 0

  pdf
}

p.stop.2 <- function(t,t.s,k.a=1,k.b=1,k.s=1,
                    l.a=1,l.b=1,l.s=1,
                    a.a=0,a.b=0,a.s=0) {
  
  if(t.s >=0) 
  p <- (1-pigt(t,k=k.a,l=l.a,a=a.a))*
    (1-pigt(t,k=k.b,l=l.b,a=a.b)
  )* digt(t-t.s,k=k.s,l=l.s,a=a.s)
  else 
  p <- (1-pigt(t+t.s,k=k.a,l=l.a,a=a.a))*(1-pigt(t+t.s,k=k.b,l=l.b,a=a.b)
  )* digt(t,k=k.s,l=l.s,a=a.s)
  p
}
p.stop.4 <- function(t,t.s,k.a=1,k.b=1,k.c=1,k.d=1,k.s=1,
                    l.a=1,l.b=1,l.c=1,l.d=1,l.s=1,
                    a.a=0,a.b=0,a.c=0,a.d=0,a.s=0) {
  if(t.s >=0) 
  (1-pigt(t,k=k.a,l=l.a,a=a.a)
   )*(1-pigt(t,k=k.b,l=l.b,a=a.b)
   )*(1-pigt(t,k=k.c,l=l.c,a=a.c)
   )*(1-pigt(t,k=k.d,l=l.d,a=a.d)
   )* digt(t-t.s,k=k.s,l=l.s,a=a.s)
  else
  (1-pigt(t+t.s,k=k.a,l=l.a,a=a.a)
   )*(1-pigt(t+t.s,k=k.b,l=l.b,a=a.b)
   )*(1-pigt(t+t.s,k=k.c,l=l.c,a=a.c)
   )*(1-pigt(t+t.s,k=k.d,l=l.d,a=a.d)
   )* digt(t,k=k.s,l=l.s,a=a.s)
}
p.stop.6 <- function(t,t.s,k.a=1,k.b=1,k.c=1,k.d=1,k.e=1,k.f=1,k.s=1,
                    l.a=1,l.b=1,l.c=1,l.d=1,l.e=1,l.f=1,l.s=1,
                    a.a=0,a.b=0,a.c=0,a.d=0,a.e=0,a.f=0,a.s=0) {

  if(t.s >=0)
  (1-pigt(t,k=k.a,l=l.a,a=a.a)
   )*(1-pigt(t,k=k.b,l=l.b,a=a.b)
   )*(1-pigt(t,k=k.c,l=l.c,a=a.c)
   )*(1-pigt(t,k=k.d,l=l.d,a=a.d)
   )*(1-pigt(t,k=k.e,l=l.e,a=a.e)
   )*(1-pigt(t,k=k.f,l=l.f,a=a.f)
   )* digt(t-t.s,k=k.s,l=l.s,a=a.s)
  else
  (1-pigt(t+t.s,k=k.a,l=l.a,a=a.a)
   )*(1-pigt(t+t.s,k=k.b,l=l.b,a=a.b)
   )*(1-pigt(t+t.s,k=k.c,l=l.c,a=a.c)
   )*(1-pigt(t+t.s,k=k.d,l=l.d,a=a.d)
   )*(1-pigt(t+t.s,k=k.e,l=l.e,a=a.e)
   )*(1-pigt(t+t.s,k=k.f,l=l.f,a=a.f)
   )* digt(t,k=k.s,l=l.s,a=a.s)
}

p.2 <- function(t.s,k.a=1,k.b=1,k.s=1,l.a=1,l.b=1,l.s=1,a.a=0,a.b=0,a.s=0) {
  p <- rep(0,times=length(t.s))

  pars.u <- unique(cbind(t.s,k.a,k.b,k.s,l.a,l.b,l.s,a.a,a.b,a.s))

  for (i in 1:length(pars.u[,1])) {
    if(pars.u[i,1]<Inf) {

      u <- integrate(p.stop.2,
           lower=pars.u[i,1],upper=4000,stop.on.error=FALSE,
           t.s=pars.u[i,1],k.a=pars.u[i,2],k.b=pars.u[i,3],k.s=pars.u[i,4],
           l.a=pars.u[i,5],l.b=pars.u[i,6],l.s=pars.u[i,7],
           a.a=pars.u[i,8],a.b=pars.u[i,9],a.s=pars.u[i,10])$value

      p[t.s==pars.u[i,1] &
        k.a==pars.u[i,2] & k.b==pars.u[i,3] & k.s==pars.u[i,4] &
        l.a==pars.u[i,5] & l.b==pars.u[i,6] & l.s==pars.u[i,7] &
        a.a==pars.u[i,8] & a.b==pars.u[i,9] & a.s==pars.u[i,10]] <- u
    }}
    p
}
p.4 <- function(t.s,k.a=1,k.b=1,k.c=1,k.d=1,k.s=1,
                l.a=1,l.b=1,l.c=1,l.d=1,l.s=1,
                a.a=0,a.b=0,a.c=0,a.d=0,a.s=0) {
  p <- rep(0,times=length(t.s))
  pars.u <- unique(cbind(t.s,k.a,k.b,k.c,k.d,k.s,l.a,l.b,l.c,l.d,l.s,
                         a.a,a.b,a.c,a.d,a.s))
  for (i in 1:length(pars.u[,1])) {
    if(pars.u[i,1]<Inf) {
      u <- integrate(p.stop.4,
        lower=pars.u[i,1],upper=4000,stop.on.error=FALSE,subdivisions=500,
        t.s=pars.u[i,1],
        k.a=pars.u[i,2],k.b=pars.u[i,3],k.c=pars.u[i,4],k.d=pars.u[i,5],
                     k.s=pars.u[i,6],
        l.a=pars.u[i,7],l.b=pars.u[i,8],l.c=pars.u[i,9],l.d=pars.u[i,10],
                     l.s=pars.u[i,11],
       a.a=pars.u[i,12],a.b=pars.u[i,13],a.c=pars.u[i,14],a.d=pars.u[i,15],
                     a.s=pars.u[i,16])$value
       p[t.s==pars.u[i,1] & k.a==pars.u[i,2] & k.b==pars.u[i,3] &
         k.c==pars.u[i,4] & k.d==pars.u[i,5] & k.s==pars.u[i,6] &
         l.a==pars.u[i,7] & l.b==pars.u[i,8] & l.c==pars.u[i,9] &
         l.d==pars.u[i,10] & l.s==pars.u[i,11] & a.a==pars.u[i,12] &
         a.b==pars.u[i,13] & a.c==pars.u[i,14] & a.d==pars.u[i,15] &
         a.s==pars.u[i,16] ] <- u
    }}
    p
}
p.6 <- function(t.s,k.a=1,k.b=1,k.c=1,k.d=1,k.e=1,k.f=1,k.s=1,
                l.a=1,l.b=1,l.c=1,l.d=1,l.e=1,l.f=1,l.s=1,
                a.a=0,a.b=0,a.c=0,a.d=0,a.e=0,a.f=0,a.s=0) {
  p <- rep(0,times=length(t.s))
  pars.u <- unique(cbind(t.s,k.a,k.b,k.c,k.d,k.e,k.f,k.s,
                         l.a,l.b,l.c,l.d,l.e,l.f,l.s,
                         a.a,a.b,a.c,a.d,a.e,a.f,a.s))
  for (i in 1:length(pars.u[,1])) {

    if(pars.u[i,1]<Inf) {
      u <- integrate(p.stop.6,
         lower=pars.u[i,1],upper=4000,stop.on.error=FALSE,
         t.s=pars.u[i,1],k.a=pars.u[i,2],k.b=pars.u[i,3],
         k.c=pars.u[i,4],k.d=pars.u[i,5],k.e=pars.u[i,6],
         k.f=pars.u[i,7],k.s=pars.u[i,8],
         l.a=pars.u[i,9],l.b=pars.u[i,10],l.c=pars.u[i,11],
         l.d=pars.u[i,12],l.e=pars.u[i,13],l.f=pars.u[i,14],
         l.s=pars.u[i,15],
         a.a=pars.u[i,16],a.b=pars.u[i,17],a.c=pars.u[i,18],
         a.d=pars.u[i,19],a.e=pars.u[i,20],a.f=pars.u[i,21],
         a.s=pars.u[i,22])$value
      
      p[t.s==pars.u[i,1] & k.a==pars.u[i,2] & k.b==pars.u[i,3] &
        k.c==pars.u[i,4] & k.d==pars.u[i,5] &
        k.e==pars.u[i,6] & k.f==pars.u[i,7] &
        k.s==pars.u[i,8] &
        l.a==pars.u[i,9] & l.b==pars.u[i,10] & l.c==pars.u[i,11] &
        l.d==pars.u[i,12] & l.e==pars.u[i,13] & l.f==pars.u[i,14] &
        l.s==pars.u[i,15] &
        a.a==pars.u[i,16] & a.b==pars.u[i,17] & a.c==pars.u[i,18] &
        a.d==pars.u[i,19] & a.e==pars.u[i,20] & a.f==pars.u[i,21] &
        a.s==pars.u[i,22]] <- u
    }}
    p
}

neg.log.likelihood <- function(pars,data) {
  pars <- constraint(pars)
  
  data.t <- data.by.choices(data)
  pars.t <- pars.by.choices(pars)
  
  l.2 <- neg.log.likelihood.2(pars.t$pars.2,data.t$data.2)
  l.4 <- neg.log.likelihood.4(pars.t$pars.4,data.t$data.4)
  l.6 <- neg.log.likelihood.6(pars.t$pars.6,data.t$data.6)
  x <- l.2+l.4+l.6
  return(x)
 
  }

get.data <- function(sub,sig=NA) {
data <- scan(file='../../../all.dat',list(0,0,0,0,0,0,0,0,0,0))

subject <- data[[1]] - 7
choices <- data[[2]]

phase <- data[[3]]
stimulus <- data[[4]]

signal <- data[[5]]
ssd.code <- data[[6]]

correct <- data[[7]]

re <- data[[8]]

rt <- data[[9]]

ssd.delay <- data[[10]]

flag <- !(re==0 & signal==0)
choices <- choices[flag]
stimulus <- stimulus[flag]
phase <- phase[flag]
rt <- rt[flag]
ssd.delay <- ssd.delay[flag]
subject <- subject[flag]
re <- re[flag]
signal <- signal[flag]
flag <- !(re==7)
choices <- choices[flag]
stimulus <- stimulus[flag]
phase <- phase[flag]
rt <- rt[flag]
ssd.delay <- ssd.delay[flag]
subject <- subject[flag]
re <- re[flag]
signal <- signal[flag]

flag <- !(re==2 & choices==2)
choices <- choices[flag]
stimulus <- stimulus[flag]
phase <- phase[flag]
rt <- rt[flag]
ssd.delay <- ssd.delay[flag]
subject <- subject[flag]
re <- re[flag]
signal <- signal[flag]

flag <- !(rt < 200 & rt > 0)
choices <- choices[flag]
stimulus <- stimulus[flag]
phase <- phase[flag]
rt <- rt[flag]
ssd.delay <- ssd.delay[flag]
subject <- subject[flag]
re <- re[flag]
signal <- signal[flag]


ssd.delay[signal==0] <- Inf
stimulus <- stimulus + (1 + .5*choices-.25*choices^2)
re <- re + (.5*choices-3)

choices <- choices[phase==3]
stimulus <- stimulus[phase==3]
rt <- rt[phase==3]
ssd.delay <- ssd.delay[phase==3]
subject <- subject[phase==3]
re <- re[phase==3]
signal <- signal[phase==3]

re[re<=0] <- -1

list(rt=rt[subject==sub],
     ssd=ssd.delay[subject==sub],
     category=stimulus[subject==sub],
     resp=re[subject==sub],
     choices=choices[subject==sub])
}

data.by.choices <- function(data){
   choices <- data$choices
   min.rt <- min(data$rt[data$rt>0])
   
   data.2 <- list(rt=data$rt[data$choices==2],ssd=data$ssd[data$choices==2],category=data$category[data$choices==2],resp=data$resp[data$choices==2],min.rt=min.rt)
   data.4 <- list(rt=data$rt[data$choices==4],ssd=data$ssd[data$choices==4],category=data$category[data$choices==4],resp=data$resp[data$choices==4],min.rt=min.rt)
   data.6 <- list(rt=data$rt[data$choices==6],ssd=data$ssd[data$choices==6],category=data$category[data$choices==6],resp=data$resp[data$choices==6],min.rt=min.rt)
   list(data.2=data.2,data.4=data.4,data.6=data.6)
 }

pars.by.choices <- function(pars){
   pars.2 <- c(pars[1:7],pars[22:23])
   pars.4 <- c(pars[8:14],pars[22:23])
   pars.6 <- c(pars[15:21],pars[22:23])
   list(pars.2=pars.2,pars.4=pars.4,pars.6=pars.6)
 }


all.pars <- function(pars.2,pars.4,pars.6) c(pars.2[1:7],pars.4[1:7],pars.6[1:9])

