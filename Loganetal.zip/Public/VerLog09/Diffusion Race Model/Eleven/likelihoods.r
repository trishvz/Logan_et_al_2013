# R Code to fit the models reported in Logan, Van Zandt, Verbruggen, and
# Wagenmakers (in press).  On the ability to inhibit thought and action:
# General and special theories of an act of control.  Psychological Review.
#
# Copyright (C) 2013  Trisha Van Zandt
#
# This program is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free
# Software Foundation, either version 3 of the License, or (at your option)
# any later version.
#
#This program is distributed in the hope that it will be useful, but WITHOUT
#ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
#FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
#more details.
#
#To read the GNU General Public License, see <http://www.gnu.org/licenses/>.
neg.log.likelihood.0<- function(pars,data) {
  t <- data$rt 
  t.s <- data$ssd 
  stimulus <- data$stimulus 
  resp <- data$resp 
  context <- data$context 
  small <- 1e-6
  min.rt <- data$min.rt
  max.rt <- max(data$rt)


  k <- .1+3999.9/(1+exp(pars[1:2]))  
  k.s <- rep(.1 + 3999.9/(1+exp(pars[3])),times=length(resp))
  
  k.a <- rep(NA,times=length(resp))
  k.b <- rep(NA,times=length(resp))
  l.a <- rep(NA,times=length(resp))
  l.b <- rep(NA,times=length(resp))

  mu <- 10000/(1+exp(pars[4:5])) 

  l.1 <- mu[1] + (stimulus==1)*10000/(1+exp(pars[6]))
  l.2 <- mu[2] + (stimulus==2)*10000/(1+exp(pars[7]))
  l.s <- rep(20000/(1+exp(pars[8])),times=length(stimulus))

  a <- 1*max(k)/(1+ exp(pars[9]))
  a.s <- 1*k.s/(1+exp(pars[10]))

  a.a <- rep(NA,times=length(resp))
  a.b <- rep(NA,times=length(resp))


  for (i in 1:length(resp)) {
    n <- resp[i]
    if(n==1 | n<0) {
      l.a[i] <- l.1[i]
      l.b[i] <- l.2[i]
      k.a[i] <- k[1]
      k.b[i] <- k[2]
      a.a[i] <- a
      a.b[i] <- a
    }
    if(n==2) {
      l.a[i] <- l.2[i]
      l.b[i] <- l.1[i]
      k.a[i] <- k[2]
      k.b[i] <- k[1]
      a.a[i] <- a
      a.b[i] <- a
    }
}

  t.0 <- .1*min.rt + .9*min.rt/(1+exp(pars[11])) 
  t.1 <- 4000./(1+exp(pars[12])) 

  y <- f.2(t-t.0,t.s+t.1-t.0,k.a,k.b,k.s,l.a,l.b,l.s,a.a,a.b,a.s) 

  ly <- log(y) 
  ly[ly==-Inf] <- -750 
  -sum(ly) 
}


transform <- function(pars,t.m=0){

    pars <- constraint(pars)
    k.1 <- .1+3999.9/(1+exp(pars[1:3]))

    mu.1 <- 10000/(1+exp(pars[4:5]))
    l1 <- c(mu.1,0) +
          c(10000/(1+exp(pars[6:7])),20000/(1+exp(pars[8])))

    a.1 <- c(max(k.1[1:2]),k.1[3])/(1+exp(pars[9:10]))

    t.11 <- .1*t.m + .9*t.m/(1+exp(pars[11]))
    t.12 <- 4000./(1+exp(pars[12]))
    t.1 <- c(t.11,t.12)
                             
                        
    k.2 <- .1+3999.9/(1+exp(pars[13:15]))

    mu.2 <- 10000/(1+exp(pars[16:17]))
    l2 <- c(mu.2,0) +
          c(10000/(1+exp(pars[18:19])),20000/(1+exp(pars[20])))

    a.2 <- c(max(k.2[1:2]),k.2[3])/(1+exp(pars[21:22]))
                        

    t.21 <- .1*t.m + .9*t.m/(1+exp(pars[23]))
    t.22 <- 4000./(1+exp(pars[24]))
    t.2 <- c(t.21,t.22)

    list(k=c(k.1,k.2),
         mu=c(mu.1,mu.2),
         l=c(l1,l2),
         a=c(a.1,a.2),
         t.0=c(t.1,t.2))

}

