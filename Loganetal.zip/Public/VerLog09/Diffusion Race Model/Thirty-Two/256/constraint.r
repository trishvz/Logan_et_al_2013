constraint <- function(pars) {

   pars[2] <- pars[1]
   pars[14] <- pars[13]
  
   pars[15] <- pars[3] 

   pars[5] <- pars[4]
   pars[17] <- pars[16]

   pars[7] <- pars[6]
   pars[19] <- pars[18]

   pars[20] <- pars[8] 

   pars[12] <- 500 

  pars
}

